# doit-esp32-devkit-kicad
DOIT Esp32 DevKit v1 KiCad component file and footprint.

No guarantees on correctness
